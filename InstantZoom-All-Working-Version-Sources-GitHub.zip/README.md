# Instant Zoom — Source Code Collection

Minecraft Java client-side zoom mod. Press and hold **C** for immediate ~4× zoom; release to return to normal FOV. The key can be changed in **Options → Controls → Key Binds**. Cinematic camera smoothing is not enabled.

This repository collects the final source snapshots shared for the Minecraft/loader versions listed below, intended to make community maintenance and porting easier.

## Versions included

| Minecraft | Loader | Source version | Location |
|---|---|---|---|
| 1.20.1 | Fabric | 1.0.1 | [`1.20.1/fabric/`](1.20.1/fabric/) |
| 1.20.1 | Forge | 1.0.2 | [`1.20.1/forge/`](1.20.1/forge/) |
| 1.21.1 | Fabric | 1.1.0 | [`1.21.1/fabric/`](1.21.1/fabric/) |
| 1.21.1 | Forge | 1.1.1 | [`1.21.1/forge/`](1.21.1/forge/) |
| 1.21.1 | Neoforge | 1.1.0 | [`1.21.1/neoforge/`](1.21.1/neoforge/) |
| 26.3 | Fabric | 1.1.7 | [`26.3/fabric/`](26.3/fabric/) |
| 26.3 | Forge | 1.1.1 | [`26.3/forge/`](26.3/forge/) |
| 26.3 | Neoforge | 1.1.1 | [`26.3/neoforge/`](26.3/neoforge/) |

## GitHub upload

Extract this ZIP, create a new GitHub repository and upload **the contents of this folder**, keeping the version and loader subfolders. Keep the root `README.md` and `LICENSE`.

## Building / porting

- Each port contains its own `src/main/java` and `src/main/resources` files; do **not** combine sources from different Minecraft/loader versions into a single mod JAR.
- The Fabric 26.3 folder includes its original Gradle build scripts. **The other folders are source snapshots, not complete independently buildable Gradle projects.** For them, generate a project with the official Fabric Loom example, Forge MDK, or NeoForge MDK matching that exact game version, then merge its `src/main` folder and adjust dependencies/mod metadata as needed.
- The files preserve the previous source implementations and metadata. They are **not freshly compiled or runtime-tested as part of creating this collection**.
- For Minecraft 26.3, input moved to SDL and loader keybinding/FOV APIs differ from 1.21.1; use `26.3/fabric/` or the 26.3 Forge/NeoForge implementation as the porting reference.
- In a port, preserve the existing `instantzoom` mod ID and the selected loader's keybinding registration conventions.
- Build using the official loader's mapped and reobfuscated toolchain, not synthetic API stubs. Always test both startup and in-game zoom before publishing.

## Features

- Client-side zoom; default hold-to-zoom **C** binding, rebindable.
- Instantly divides FOV by 4 (approximately 4× magnification).
- No cinematic camera interpolation.

## License

MIT — see [`LICENSE`](LICENSE).
