# Porting Instant Zoom to Another Minecraft Version

1. Choose the closest supported loader and Minecraft version under this repository.
2. Create a fresh project with the official version-matched Fabric example, Forge MDK or NeoForge MDK.
3. Copy or adapt Java source and resources from `src/main`, retaining the `instantzoom` mod ID.
4. Register the zoom key using the target loader’s current keymapping event; set its default to C and give it a dedicated category.
5. Apply a `0.25` multiplier to the rendered world-camera FOV while that *assigned* key is down. Do not turn on smooth/cinematic camera behaviour.
6. Verify class names, injection method descriptors, API signatures, language file and metadata in that target version. Minecraft 26.x uses SDL, whereas older versions used GLFW.
7. Use the official loader Gradle build and verify the built JAR does not include test stubs.
8. Test on the actual Minecraft client: keybind category visible, rebind works, zoom engages instantly, releasing resets FOV, no crash or noisy logging.

**Note:** Source snapshots are provided to help porting; moving files alone between game versions is unlikely to work without API changes.
